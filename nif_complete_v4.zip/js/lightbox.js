// Lightbox.js initialization
console.log("Lightbox.js loaded");
